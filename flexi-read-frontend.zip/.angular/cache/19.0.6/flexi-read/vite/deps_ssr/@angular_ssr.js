import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  AngularAppEngine,
  InlineCriticalCssProcessor,
  PrerenderFallback,
  RenderMode,
  createRequestHandler,
  destroyAngularServerApp,
  extractRoutesAndCreateRouteTree,
  getOrCreateAngularServerApp,
  getRoutesFromAngularRouterConfig,
  provideServerRoutesConfig,
  setAngularAppEngineManifest,
  setAngularAppManifest
} from "./chunk-F3CDDWV3.js";
import "./chunk-6RSY5WO7.js";
import "./chunk-PNLSB6IJ.js";
import "./chunk-3ITFQUBI.js";
import "./chunk-4JHMHJ7I.js";
import "./chunk-NIU4ZWK3.js";
import "./chunk-YVWCZT7M.js";
import "./chunk-3AYOO7D2.js";
import "./chunk-ANGF2IQY.js";
export {
  AngularAppEngine,
  PrerenderFallback,
  RenderMode,
  createRequestHandler,
  provideServerRoutesConfig,
  InlineCriticalCssProcessor as ɵInlineCriticalCssProcessor,
  destroyAngularServerApp as ɵdestroyAngularServerApp,
  extractRoutesAndCreateRouteTree as ɵextractRoutesAndCreateRouteTree,
  getOrCreateAngularServerApp as ɵgetOrCreateAngularServerApp,
  getRoutesFromAngularRouterConfig as ɵgetRoutesFromAngularRouterConfig,
  setAngularAppEngineManifest as ɵsetAngularAppEngineManifest,
  setAngularAppManifest as ɵsetAngularAppManifest
};
//# sourceMappingURL=@angular_ssr.js.map
