import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  require_cjs
} from "./chunk-3AYOO7D2.js";
import "./chunk-ANGF2IQY.js";
export default require_cjs();
//# sourceMappingURL=rxjs.js.map
