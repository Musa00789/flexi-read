declare module 'pdfjs-dist/legacy/build/pdf';
